Instructions:
After downloading the ZIP file (go to the green "code" button and hit 'download zip')
Go into your browser, and enter the website; "about:blank"
Then go into file explorer, and drag and drop the unzipped file into the blank space. Then click the file that says 'start.html'.
(Hope this helped.)

Second Option: Go to gamepubsite.github.io and play normally.
